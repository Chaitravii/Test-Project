﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.Data.SqlClient;
using Notification_Project.Hubs;

namespace Notification_Project
{
    public class NotificationComponent
    {
        public void RegisterNotification(DateTime currentTime)
        { 
            string conStr = "Server=.\\SQLEXPRESS;Database=NotificationDB;Trusted_Connection=True;TrustServerCertificate=True;";
            string sqlCommand = @"select [UserName],[UserQuery] from [dbo].[Notifications] where [AddedOn]";
            using (SqlConnection con = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand(sqlCommand, con);
                if(con.State!= System.Data.ConnectionState.Open) 
                {
                    con.Open();
                }
                cmd.Notification = null;
                SqlDependency sqlDep = new SqlDependency(cmd);
                sqlDep.OnChange += sqlDep_OnChange;
                using (SqlDataReader reader = cmd.ExecuteReader()) { }
            }
        }

        private void sqlDep_OnChange(object sender, SqlNotificationEventArgs e)
        {
            if(e.Type==SqlNotificationType.Change)
            {
                SqlDependency sqlDep = (SqlDependency)sender;
                sqlDep.OnChange += sqlDep_OnChange;
                var motificationHub = GlobalHost.ConnectionManager.GetHubContext<IHub>();
                motificationHub.Clients.All.notify("Is added");
            }
            RegisterNotification(DateTime.Now);

        }
    }
}
