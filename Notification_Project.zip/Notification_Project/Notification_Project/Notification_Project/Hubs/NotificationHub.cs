﻿using Microsoft.AspNetCore.SignalR;

namespace Notification_Project.Hubs
{
    public class NotificationHub : Hub
    {
        //public async Task AddTask(object taskItem)
        //{
        //    await Clients.All.SendAsync("Posted Question",taskItem);
        //}
    }
}
