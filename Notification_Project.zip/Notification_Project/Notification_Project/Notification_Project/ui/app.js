// const routes=[
//     {path:'/home', component:home},
//     {path:'/notification', component:notification}
// ]

// const router=createRouter({
//    routes:routes
// });

// app.use(router);

const app = Vue.createApp({
    data: function(){
        return{
            count:0
        }
    }
})

app.component('navbar',{
    template:'<nav class="navbar navbar-expand-sm bg-light navbar-dark"><ul class="navbar-nav"><li class="nav-item m-1"><router-link class="btn btn-light btn-outline-primary" to="/home">Home</router-link></li><li class="nav-item m-1"><router-link class="btn btn-light btn-outline-primary" to="/notification">Notifications<span>{{count}}</span></router-link></li></ul></nav><router-view></router-view>'
})

app.mount('#app')
