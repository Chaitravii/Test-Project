const home = {
    template:'<span>Enter Your Name</span><br><input><br><br><span>Enter Your Query</span><br><input><br><br><button @click="addQuery()">Submit</button>',
    methods:{
        addQuery(){
            axios.post(variables.API_URL+"home",{
            UserName:this.UserName,
            UserQuery:this.UserQuery
        })
        .then((response)=>{
            alert(response.data);
        });
        }
    }
}