global using Notification_Project.Models;
global using Notification_Project.Data;
using Notification_Project.Models.Services;
using System.Runtime.CompilerServices;
using Notification_Project.Hubs;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers()
.AddJsonOptions(options => options.JsonSerializerOptions.DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull);
builder.Services.AddSignalR();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<INotificationsService, NotificationsService>();
builder.Services.AddScoped<IHomeService, HomeService>();
builder.Services.AddDbContext<DataContext>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseEndpoints(x =>
{
    x.MapHub<NotificationHub>("/notify");
});

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
