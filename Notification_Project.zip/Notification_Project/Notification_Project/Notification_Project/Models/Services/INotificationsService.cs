﻿namespace Notification_Project.Models.Services
{
    public interface INotificationsService
    {
        Task<List<Notifications>> GetNotifications();
    }
}
