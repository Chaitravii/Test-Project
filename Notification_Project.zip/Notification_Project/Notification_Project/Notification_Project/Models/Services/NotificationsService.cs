﻿namespace Notification_Project.Models.Services
{
    public class NotificationsService : INotificationsService
    {
        private static List<Notifications> objNotifications = new List<Notifications> { };
        private readonly DataContext _context;

        public NotificationsService(DataContext context) 
        {
            _context = context;
        }
        public async Task<List<Notifications>> GetNotifications()
        {
            return await _context.Notifications.ToListAsync();
        }
    }
}
