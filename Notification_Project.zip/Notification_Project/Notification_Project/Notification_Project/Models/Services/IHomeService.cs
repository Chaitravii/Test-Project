﻿namespace Notification_Project.Models.Services
{
    public interface IHomeService
    {
        Task<List<Notifications>> AddQuery(Notifications objRequest);
    }
}
