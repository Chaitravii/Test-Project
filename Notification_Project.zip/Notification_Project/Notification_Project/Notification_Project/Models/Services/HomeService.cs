﻿namespace Notification_Project.Models.Services
{
    public class HomeService : IHomeService
    {
        private static List<Notifications> objNotifications = new List<Notifications> { };
        private readonly DataContext _context;

        public HomeService(DataContext context)
        {
            _context = context;
        }

        public async Task<List<Notifications>> AddQuery(Notifications objRequest)
        {
            _context.Notifications.Add(objRequest);
            await _context.SaveChangesAsync();
            return await _context.Notifications.ToListAsync();
        }

    }
}
