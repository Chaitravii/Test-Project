﻿using System.ComponentModel.DataAnnotations;

namespace Notification_Project.Models
{
    public class Notifications
    {
        [Key] public int NotificationId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserQuery { get; set; } = string.Empty;
        public bool IsRead { get; set; } = false;
    }
}
