﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Notification_Project.Models.Services;

namespace Notification_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private readonly IHomeService _homeService;
        public HomeController(IHomeService homeService)
        {
            _homeService = homeService;
        }


        [HttpPost]
        public async Task<ActionResult<List<Notifications>>> AddQuery(Notifications objRequest)
        {
            var result = await _homeService.AddQuery(objRequest);
            return Ok(result);
        }
    }
}
