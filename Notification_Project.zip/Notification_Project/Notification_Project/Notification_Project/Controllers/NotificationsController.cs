﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Notification_Project.Models.Services;

namespace Notification_Project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        private readonly INotificationsService _notificationsService;
        public NotificationsController(INotificationsService notificationService)
        {
            _notificationsService = notificationService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Notifications>>> GetNotifications()
        {
            return await _notificationsService.GetNotifications();
        }

    }
}
